create table logindetails;
Drop table LOGINDETAILS;



