package com.wellspringtravels.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wellspringtravels.model.User;

public interface UserRepository extends JpaRepository<User, Long> {


    User findByUsername(String username);

}

