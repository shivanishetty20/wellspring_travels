package com.wellspringtravels.controller;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


import com.wellspringtravels.model.Trip;
import com.wellspringtravels.service.TripService;

@Controller

public class TripController {
	private static final Logger log = Logger.getLogger(LoginController.class.getName());

	@Autowired
	private final TripService tripService;

	public TripController(TripService tripService) {
		this.tripService = tripService;
	}


	@GetMapping("/trips")
	public String showTrips(Model model) {
	    List<Trip> trips = tripService.getAllTrips();
	    log.info("Retrieving " + trips.size() + " trips.  " + trips.toString());
	    model.addAttribute("trips", trips);
	    //log.info("trips  " + trips.containsAll(trips));
	    log.info("Retrieved " + trips.size() + " trips.  " + trips.toString());
	    return "trips";
	}

}
