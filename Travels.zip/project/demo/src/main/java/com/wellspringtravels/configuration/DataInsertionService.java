package com.wellspringtravels.configuration;


import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wellspringtravels.model.Admin;
import com.wellspringtravels.model.Trip;
import com.wellspringtravels.repository.AdminRepository;
import com.wellspringtravels.repository.TripRepository;


@Service
public class DataInsertionService {

    @Autowired
    private TripRepository tripDataRepository;
    
    @Autowired
    private AdminRepository adminDataRepository;

    public void insertSampleData() {
    	Trip trip1 = new Trip();
    	trip1.setId(1);
        trip1.setName("Trip 1");
        trip1.setDestination("Destination 1");
        trip1.setCost(10000.0);
        trip1.setTransportationCost(3000.0);
        trip1.setAccommodationCost(4000.0);
        trip1.setFoodCost(2000.0);
        trip1.setGuideFee(1000.0);
        trip1.setDuration(5);

        Trip trip2 = new Trip();
        trip2.setId(2);
        trip2.setName("Trip 2");
        trip2.setDestination("Destination 2");
        trip2.setCost(12000.0);
        trip2.setTransportationCost(3500.0);
        trip2.setAccommodationCost(4500.0);
        trip2.setFoodCost(2200.0);
        trip2.setGuideFee(1800.0);
        trip2.setDuration(7);

        Trip trip3 = new Trip();
        trip3.setId(3);
        trip3.setName("Trip 3");
        trip3.setDestination("Destination 3");
        trip3.setCost(9300.0);
        trip3.setTransportationCost(2800.0);
        trip3.setAccommodationCost(3800.0);
        trip3.setFoodCost(1800.0);
        trip3.setGuideFee(900.0);
        trip3.setDuration(4);
        
        tripDataRepository.saveAll(Arrays.asList(trip1, trip2, trip3));
        
        
        Admin admin1 = new Admin();
        admin1.setId(1);
        admin1.setUsername("admin1");
        admin1.setPassword("root1");

        Admin admin2 = new Admin();
        admin2.setId(2);
        admin2.setUsername("admin2");
        admin2.setPassword("root2");
        
        Admin admin3 = new Admin();
        admin3.setId(3);
        admin3.setUsername("admin3");
        admin3.setPassword("root3");
        
        adminDataRepository.saveAll(Arrays.asList(admin1, admin2, admin3));
        
        

    }
}
