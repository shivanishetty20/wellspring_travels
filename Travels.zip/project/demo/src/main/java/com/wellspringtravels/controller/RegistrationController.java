package com.wellspringtravels.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wellspringtravels.model.User;
import com.wellspringtravels.service.UserService;

@Controller

public class RegistrationController {

    @Autowired
    private UserService userService;

    @RequestMapping("/registration")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "registration"; // Renders the registration.jsp view
    }

    @PostMapping("/registration")
    public String registerUser(@ModelAttribute("user") User user, Model model) {
        try {
            userService.registerUser(user);
            return "redirect:/login"; // Redirect to the login page after successful registration
        } catch (Exception e) {
            // Handle the exception by displaying an error message to the user
            model.addAttribute("errorMessage", "Registration failed. Please try again.");
            return "registration"; // Return to the registration form with an error message
        }
    }

    }

