package com.wellspringtravels.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wellspringtravels.model.Trip;

public interface TripRepository extends JpaRepository<Trip, Integer> {




}
