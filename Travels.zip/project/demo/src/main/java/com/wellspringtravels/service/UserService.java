package com.wellspringtravels.service;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wellspringtravels.model.User;
import com.wellspringtravels.repository.UserRepository;

@Service
public class UserService {

    // Create a logger for this class
    private static final Logger log = Logger.getLogger(UserService.class.getName());

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) throws Exception {
        // Log user data before saving
        log.info("User data to be saved: " + user.getUsername()+ user.getPassword() + user.getId() +user.getClass().getName());

        if (userRepository.findByUsername(user.getUsername()) != null) {
            throw new Exception("Username is already taken");
        }

        User savedUser = userRepository.save(user);
        // Log the result of saving
        log.info("User data after saving: " + savedUser);

        return savedUser;
    }
}
