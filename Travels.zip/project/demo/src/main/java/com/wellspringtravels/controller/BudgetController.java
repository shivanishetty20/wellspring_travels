package com.wellspringtravels.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wellspringtravels.model.Trip;
import com.wellspringtravels.service.TripServiceImpl;

@Controller
//@RequestMapping("/budget")
public class BudgetController {

    @Autowired
    private TripServiceImpl tripServiceimpl;

    // Mapping to display the budget.jsp page
    @PostMapping("/budget")
    public String showBudgetPage(@RequestParam(value = "tripId", required = false) Integer tripId, Model model) {
        if (tripId != null) {
            Trip selectedTrip = tripServiceimpl.getTripById(tripId);
            model.addAttribute("trip", selectedTrip);
        }
        return "budget";
    }

    // Mapping to calculate the total cost and display it
    @PostMapping("/calculateTotalCost")
    public String calculateTotalCost(@RequestParam("tripId") int tripId, @RequestParam("numPersons") int numPersons, Model model) {
        Trip selectedTrip = tripServiceimpl.getTripById(tripId);
        double totalCost = tripServiceimpl.calculateBudget(tripId, numPersons);

        model.addAttribute("trip", selectedTrip);
        model.addAttribute("totalCost", totalCost);
        model.addAttribute("numPersons", numPersons);

        return "budget";
    }
}
