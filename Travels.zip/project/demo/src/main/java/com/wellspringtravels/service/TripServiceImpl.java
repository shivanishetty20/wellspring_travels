package com.wellspringtravels.service;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.web.bind.annotation.GetMapping;

import com.wellspringtravels.model.Trip;
import com.wellspringtravels.repository.TripRepository;

@Service
public class TripServiceImpl implements TripService {
    private static final Logger LOGGER = Logger.getLogger(TripServiceImpl.class.getName());

    @Autowired
    private TripRepository tripRepository;

    public TripServiceImpl(TripRepository tripRepository) {
        this.tripRepository = tripRepository;
    }


    @GetMapping("/get/{id}")
    @Override
    public Trip getTripById(int id) {
        LOGGER.info("Getting trip by ID: " + id);
        return tripRepository.findById(id).orElse(null);
    }

 

    @Override
    public double calculateTotalCost(Trip trip) {
        LOGGER.info("Calculating total cost for trip: " + trip.getName());
        double transportationCost = trip.getTransportationCost();
        double accommodationCost = trip.getAccommodationCost();
        double foodCost = trip.getFoodCost();
        //double guideFee = trip.getGuideFee();

        // Calculate the total cost
        double totalCost = transportationCost + accommodationCost + foodCost;

        // Ensure the total cost is non-negative
        if (totalCost < 0) {
            totalCost = 0;
        }

        LOGGER.info("Total cost for trip without guidefee " + trip.getName() + " is: " + totalCost);
        return totalCost;
    }
    
    //@PostMapping("/budget")
    @Override
    public double calculateBudget(int id, int numberOfPersons) {
        LOGGER.info("Calculating budget for trip with ID " + id + " for " + numberOfPersons + " persons.");
        Trip trip = getTripById(id);
        double baseCost = calculateTotalCost(trip); // Calculate base cost
        double guideFee = trip.getGuideFee();

        // Calculate cost breakdown (excluding the guide fee)
        double breakdownCost = baseCost * numberOfPersons;

        // Calculate the total cost including the guide fee
        double totalCost = breakdownCost + guideFee;

        // Ensure the total cost is non-negative
        if (totalCost < 0) {
            totalCost = 0;
        }

        LOGGER.info("Budget for trip " + trip.getName() + " for " + numberOfPersons + " persons is: " + totalCost);
        return totalCost;
    }


    @Override
    public List<Trip> getAllTrips() {
        LOGGER.info("Getting all trips.");
        return tripRepository.findAll();
    }

    @Override
    public Trip createOrUpdateTrip(Trip trip) {
        LOGGER.info("Creating or updating a trip.");
        return tripRepository.save(trip);
    }

    @Override
    public void deleteTrip(int id) {
        LOGGER.info("Deleting a trip with ID: " + id);
        tripRepository.deleteById(id);
    }
}
