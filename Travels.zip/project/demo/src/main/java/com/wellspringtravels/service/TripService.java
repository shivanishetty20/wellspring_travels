package com.wellspringtravels.service;

import java.util.List;

import com.wellspringtravels.model.Trip;

public interface TripService {
    
    Trip getTripById(int id);
    List<Trip> getAllTrips();
    
    double calculateTotalCost(Trip trip);
	double calculateBudget(int id, int numberOfPersons);
	Trip createOrUpdateTrip(Trip trip);
	void deleteTrip(int id);
}
