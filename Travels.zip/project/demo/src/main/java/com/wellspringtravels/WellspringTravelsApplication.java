package com.wellspringtravels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WellspringTravelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WellspringTravelsApplication.class, args);
	}

}
