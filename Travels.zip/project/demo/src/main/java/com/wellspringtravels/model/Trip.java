package com.wellspringtravels.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TRIPDATA")
public class Trip {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;

    private String name;

    private String destination;

    private double cost;

    @Column(name = "transportationcost")
    private double transportationCost;

    @Column(name = "accommodationcost")
    private double accommodationCost;

    @Column(name = "foodcost")
    private double foodCost;

    @Column(name = "guidefee")
    private double guideFee;

    private int duration;

    // Constructors, getters, and setters

    public Trip() {
    }

    public Trip(String name, String destination, double cost, double transportationCost, double accommodationCost, double foodCost, double guideFee, int duration) {
        this.name = name;
        this.destination = destination;
        this.cost = cost;
        this.transportationCost = transportationCost;
        this.accommodationCost = accommodationCost;
        this.foodCost = foodCost;
        this.guideFee = guideFee;
        this.duration = duration;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public double getTransportationCost() {
		return transportationCost;
	}

	public void setTransportationCost(double transportationCost) {
		this.transportationCost = transportationCost;
	}

	public double getAccommodationCost() {
		return accommodationCost;
	}

	public void setAccommodationCost(double accommodationCost) {
		this.accommodationCost = accommodationCost;
	}

	public double getFoodCost() {
		return foodCost;
	}

	public void setFoodCost(double foodCost) {
		this.foodCost = foodCost;
	}

	public double getGuideFee() {
		return guideFee;
	}

	public void setGuideFee(double guideFee) {
		this.guideFee = guideFee;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}



}
