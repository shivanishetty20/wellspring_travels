package com.wellspringtravels.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import com.wellspringtravels.model.User;
import com.wellspringtravels.model.Admin; 
import com.wellspringtravels.repository.UserRepository;
import com.wellspringtravels.repository.AdminRepository; 

import java.util.logging.Logger;

@Controller
public class LoginController {
    private static final Logger log = Logger.getLogger(LoginController.class.getName());

    @Autowired
    private UserRepository userRepo;
    
    @Autowired
    private AdminRepository adminRepo; // Inject the AdminRepository
    
    @RequestMapping("/login")
    public String showLoginPage() {
        log.info("Displaying login page.");
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(
        @RequestParam String username,
        @RequestParam String password,
        @RequestParam(value = "loginAsAdmin", required = false) boolean loginAsAdmin, // Check if the checkbox is selected
        Model model
    ) {
        log.info("Received login request for username: " + username);

        if (loginAsAdmin) {
            
            Admin admin = adminRepo.findByUsername(username);
            
            if (admin != null && admin.getPassword().equals(password)) {
                // Admin authentication successful
                log.info("Admin authentication successful for username: " + username);
                return "redirect:http://localhost:8080/swagger-ui/index.html"; // Redirect to the admin home page
            } else {
                // Admin authentication failed; show an error message
                log.warning("Admin authentication failed for username: " + username);
                model.addAttribute("error", "Admin authentication failed.");
                return "login";
            }
        } else {
            // User login
            User user = userRepo.findByUsername(username);

            if (user != null && user.getPassword().equals(password)) {
                // User authentication successful
                log.info("User authentication successful for username: " + username);
                return "home"; // Redirect to the user home page
            } else {
                // User authentication failed; show an error message
                log.warning("User authentication failed for username: " + username);
                model.addAttribute("error", "User authentication failed.");
                return "login";
            }
        }
    }
}
